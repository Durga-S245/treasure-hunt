TREASURE HUNT QR QUIZ

This folder contains 20 question pages with clickable A/B/C/D answers.

IMPORTANT:
QR codes must point to a public website. I have prepared the pages so they can be hosted on GitHub Pages.

Suggested public base URL:
https://YOUR-USERNAME.github.io/treasure-hunt

After hosting this folder at that URL, each QR should point to:
https://YOUR-USERNAME.github.io/treasure-hunt/q1.html
...
https://YOUR-USERNAME.github.io/treasure-hunt/q20.html

HOW TO HOST FREE USING GITHUB PAGES:
1. Create a GitHub repository named: treasure-hunt
2. Upload all files in this folder.
3. In the repository, open Settings -> Pages.
4. Select Deploy from branch -> main -> /root.
5. GitHub will give you a public URL like:
   https://YOUR-USERNAME.github.io/treasure-hunt/
6. Replace YOUR-USERNAME in the QR destination URLs when generating the final QR codes.

The question pages already have clickable options and answer checking.
